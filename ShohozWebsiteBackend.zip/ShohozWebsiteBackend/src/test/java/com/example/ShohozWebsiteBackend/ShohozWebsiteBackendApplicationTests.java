package com.example.ShohozWebsiteBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShohozWebsiteBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
