package com.example.ShohozWebsiteBackend.controller;


import com.example.ShohozWebsiteBackend.model.Paribahon;
import com.example.ShohozWebsiteBackend.service.ParibahonService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@RestController
@RequestMapping("")
@CrossOrigin(origins = "http://localhost:4200")
@RequiredArgsConstructor
public class ParibahonController {
    private final ParibahonService paribahonService;
    @GetMapping("/getParibahon")
    public List<Paribahon> getAllParibahon()
    {
        return paribahonService.getAllParibahon();
    }

    @PostMapping("/createParibahon")
    public Paribahon createParibahon(@RequestBody Paribahon p)
    {
        return paribahonService.createParibahon(p);
    }
    @GetMapping("/getParibahon/{id}")
    public ResponseEntity<Paribahon> getParibahonById(@PathVariable Long id) {
        Paribahon paribahon = paribahonService.getParibahonById(id);
        if (paribahon != null) {
            return ResponseEntity.ok(paribahon);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
