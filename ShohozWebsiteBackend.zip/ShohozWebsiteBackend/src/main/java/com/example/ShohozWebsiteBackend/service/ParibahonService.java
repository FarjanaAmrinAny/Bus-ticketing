package com.example.ShohozWebsiteBackend.service;

import com.example.ShohozWebsiteBackend.model.Paribahon;
import com.example.ShohozWebsiteBackend.repository.ParibahonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ParibahonService {
    private final ParibahonRepository paribahonRepository;
    public List<Paribahon> getAllParibahon()
    {
        return paribahonRepository.findAll();
    }
    public Paribahon createParibahon(Paribahon p)
    {
        return paribahonRepository.save(p);
    }
    public Paribahon getParibahonById(Long id) {
        return paribahonRepository.findById(id).orElse(null);
    }
}
