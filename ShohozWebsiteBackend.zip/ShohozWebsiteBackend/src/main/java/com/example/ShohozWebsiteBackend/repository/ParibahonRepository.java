package com.example.ShohozWebsiteBackend.repository;

import com.example.ShohozWebsiteBackend.model.Paribahon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ParibahonRepository extends JpaRepository<Paribahon,Long> {
}
