package com.example.ShohozWebsiteBackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShohozWebsiteBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShohozWebsiteBackendApplication.class, args);
	}

}
