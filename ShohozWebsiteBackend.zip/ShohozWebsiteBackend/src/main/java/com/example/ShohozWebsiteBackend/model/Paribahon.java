package com.example.ShohozWebsiteBackend.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Paribahon {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 50)
    private String paribahonName;
    @Column(nullable = false, length = 50)
    private String paribahonType;
    private int startingTime;
    private int endingTime;
    private int price;
}
