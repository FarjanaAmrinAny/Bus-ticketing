package com.example.ShohozWebsiteBackend.controller;

import com.example.ShohozWebsiteBackend.model.BoardingPoint;
import com.example.ShohozWebsiteBackend.service.BoardingPointService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@RestController
@RequestMapping("")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200")
public class BoardingPointController {
    private final BoardingPointService boardingPointService;
    @GetMapping("/getAllBoardingPoint")
    public List<BoardingPoint> getAllBoardingPoint()
    {
        return boardingPointService.getAllBoardingPoint();
    }
    @PostMapping("/createBoardingPoint")
    public BoardingPoint createBoardingPoint(@RequestBody BoardingPoint b)
    {
        return boardingPointService.createBoardingPoint(b);
    }
}
