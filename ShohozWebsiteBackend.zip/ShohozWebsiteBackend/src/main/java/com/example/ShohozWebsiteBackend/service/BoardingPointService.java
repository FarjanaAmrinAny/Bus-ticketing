package com.example.ShohozWebsiteBackend.service;

import com.example.ShohozWebsiteBackend.model.BoardingPoint;
import com.example.ShohozWebsiteBackend.repository.BoardingPointRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BoardingPointService {
    private final BoardingPointRepository boardingPointRepository;
    public List<BoardingPoint> getAllBoardingPoint()
    {
        return boardingPointRepository.findAll();
    }
    public BoardingPoint createBoardingPoint(BoardingPoint b)
    {
        return boardingPointRepository.save(b);
    }
}
